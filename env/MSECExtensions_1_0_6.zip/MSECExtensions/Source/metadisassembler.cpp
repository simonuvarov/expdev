//
// metadisassembler.cpp
//
// The MSEC Debugger Extension Metadisassembler
//
//
// Developed by the Microsoft Security Engineering Center (MSEC)
// Copyright 2008-2009, Microsoft Corporation
//
//	Microsoft Public License (Ms-PL)
//	This license governs use of the accompanying software. If you use the software, you accept this license. If you do not accept the license, do not use the software.
//
//	Definitions
//		The terms "reproduce," "reproduction," "derivative works," and "distribution" have the same meaning here as under U.S. copyright law. A "contribution" is the original software, or any additions or changes to the software. A "contributor" is any person that distributes its contribution under this license. "Licensed patents" are a contributor's patent claims that read directly on its contribution.
//	Grant of Rights
//		(A) Copyright Grant- Subject to the terms of this license, including the license conditions and limitations in section 3, each contributor grants you a non-exclusive, worldwide, royalty-free copyright license to reproduce its contribution, prepare derivative works of its contribution, and distribute its contribution or any derivative works that you create.
//		(B) Patent Grant- Subject to the terms of this license, including the license conditions and limitations in section 3, each contributor grants you a non-exclusive, worldwide, royalty-free license under its licensed patents to make, have made, use, sell, offer for sale, import, and/or otherwise dispose of its contribution in the software or derivative works of the contribution in the software.
//	Conditions and Limitations
//		(A) No Trademark License- This license does not grant you rights to use any contributors' name, logo, or trademarks. 
//		(B) If you bring a patent claim against any contributor over patents that you claim are infringed by the software, your patent license from such contributor to the software ends automatically. 
//		(C) If you distribute any portion of the software, you must retain all copyright, patent, trademark, and attribution notices that are present in the software. 
//		(D) If you distribute any portion of the software in source code form, you may do so only under this license by including a complete copy of this license with your distribution. If you distribute any portion of the software in compiled or object code form, you may only do so under a license that complies with this license. 
//		(E) The software is licensed "as-is." You bear the risk of using it. The contributors give no express warranties, guarantees, or conditions. You may have additional consumer rights under your local laws which this license cannot change. To the extent permitted under your local laws, the contributors exclude the implied warranties of merchantability, fitness for a particular purpose and non-infringement.
//


#define METADISASSEMBLER_MODULE
#include "stdafx.h"
#include "metadisassembler.h"
#include "metadisassembler_x86.h"
#include "metadisassembler_x64.h"

///
/// Is the string in the specified set
bool
IsStringInSet( __in PCWSTR pwzString, size_t cchString, __in PCWSTR *ppwzSet )
{
	while( *ppwzSet != NULL )
	{
		if( wcsncmp( pwzString, *ppwzSet, cchString ) == 0 )
		{
			return( true );
		}

		ppwzSet++;
	}

	return( false );
}

///
/// Get any register aliases for the register passed in. This is heavily used in the x86/x64 meta-disassembly, to map ah, al, ax, eax, and rax together, for example
const OPERAND *
GetRegisterAliases( ULONG dwProcessor, PCWSTR pwzRegister, size_t cchRegister, TAINT_TRACKING_MODE eMode )
{
	OPERAND *pRegisterAliases = NULL;

	switch( dwProcessor )
	{
		case IMAGE_FILE_MACHINE_I386:
			if( eMode == SET_TAINT )
			{
				pRegisterAliases = X86_REGISTER_TAINT_ALIASES;
			}
			else if( eMode == CLEAR_TAINT )
			{
				pRegisterAliases = X86_REGISTER_CLEAR_ALIASES;
			}
			else
			{
				return( NULL );
			}
			break;

		case IMAGE_FILE_MACHINE_ARM:
			return( NULL );

		case IMAGE_FILE_MACHINE_AMD64:
			if( eMode == SET_TAINT )
			{
				pRegisterAliases = X64_REGISTER_TAINT_ALIASES;
			}
			else if( eMode == CLEAR_TAINT )
			{
				pRegisterAliases = X64_REGISTER_CLEAR_ALIASES;
			}
			else
			{
				return( NULL );
			}
			break;

		default:
			return( NULL );
	}

	// Search through the alias list	
	while( pRegisterAliases->pwzOperand != NULL )
	{
		OPERAND *pComparison = pRegisterAliases;

		while( pComparison->pwzOperand != NULL )
		{
			if( (cchRegister == pComparison->cchOperand) &&
				(wcsncmp( pwzRegister, pComparison->pwzOperand, cchRegister ) == 0) )
			{
				return( pRegisterAliases );
			}
			else
			{
				// Skip to the end of this list, because we only compare the first registers in each list
				while( pComparison->pwzOperand != NULL )
				{
					pComparison++;
				}
			}
		}

		pRegisterAliases = pComparison + 1;
	}

	return( NULL );
}

///
/// Disassemble the instruction at the given address, creating an instruction object
///
bool
Disassemble( const DEBUGGER_CONTROLS &objControls, ULONG64 offAddress, ULONG dwProcessor, INSTRUCTION *pInstruction )
{
	// Disassemble the instruction
	ULONG cchInstruction;
	ULONG dwAssemblyOptions;
	HRESULT dwResult;

	objControls.pDebugControl->GetAssemblyOptions( &dwAssemblyOptions );
	objControls.pDebugControl->SetAssemblyOptions( dwAssemblyOptions & ~(DEBUG_ASMOPT_NO_CODE_BYTES | DEBUG_ASMOPT_SOURCE_LINE_NUMBER) );
	objControls.pDebugControl->DisassembleWide( offAddress, 0, NULL, 0, &cchInstruction, &pInstruction->offNextInstruction );
	pInstruction->pwzInstructionBuffer = new WCHAR[cchInstruction + 1];

	if( pInstruction->pwzInstructionBuffer == NULL )
	{
		return( false );
	}

	dwResult = objControls.pDebugControl->DisassembleWide( offAddress, 0, (PWSTR) pInstruction->pwzInstructionBuffer, cchInstruction + 1, NULL, &pInstruction->offNextInstruction );
	objControls.pDebugControl->SetAssemblyOptions( dwAssemblyOptions );

	if( dwResult != S_OK )
	{
		return( false );
	}
	else
	{
		pInstruction->offAddress = offAddress;
		_wcslwr_s( (PWSTR) pInstruction->pwzInstructionBuffer, cchInstruction );
	}

	// Check for disassembly errors that would cause infinite loops, this is usually due to a mismatch
	// between the debugger machine mode and the process machine mode (x86 versus x64)
	if( pInstruction->offAddress == pInstruction->offNextInstruction )
	{
		return( false );
	}

	// Parse the fields for the continued processing
	PWSTR pwzIndex = (PWSTR) pInstruction->pwzInstructionBuffer;
	pInstruction->pwzAddress = (PCWSTR) pwzIndex ;
	ParseDisassemblyFieldInPlace( &pwzIndex, NULL );
	pInstruction->pwzOpCode = (PCWSTR) pwzIndex;
	ParseDisassemblyFieldInPlace( &pwzIndex, NULL );
	pInstruction->pwzMnemonic = (PCWSTR) pwzIndex;
	ParseDisassemblyFieldInPlace( &pwzIndex, (dwProcessor == IMAGE_FILE_MACHINE_I386 ) ? X86_MNEMONIC_PREFIXES : (dwProcessor == IMAGE_FILE_MACHINE_AMD64) ? X64_MNEMONIC_PREFIXES : NULL );
	pInstruction->pwzArguments = (PCWSTR) pwzIndex;
	
	if( pInstruction->pwzArguments != NULL )
	{
		size_t cchArguments = wcslen( pInstruction->pwzArguments );

		if( cchArguments > 0 )
		{
			if( pInstruction->pwzArguments[cchArguments - 1] == '\n' )
			{
				((PWSTR) pInstruction->pwzArguments)[cchArguments - 1] = '\0';
			}
		}
	}

	// Check for invalid op codes
	if( *pInstruction->pwzMnemonic == '?' )
	{
		return( false );
	}

	// Classify the instruction
	//
	// Note that we don't consider our inability to match an instruction to be an error here, we'll continue with it
	// until we find an error in the actual disassembly routines (above)
	switch( dwProcessor )
	{
		case IMAGE_FILE_MACHINE_I386:
			{
				ClassifyX86Instruction( pInstruction );
				return( true );
			}

		case IMAGE_FILE_MACHINE_AMD64:
			{
				ClassifyX64Instruction( pInstruction );
				return( true );
			}

		default:
			return( false );
	}
}

///
/// Parse out a disassembly field in place, replacing spaces with null terminators
void
ParseDisassemblyFieldInPlace( __in PWSTR *ppwzIndex, __in_opt PCWSTR *ppwzValidPrefixes )
{
	PWSTR pwzStart = *ppwzIndex;
	bool fInField = true;

	while(  **ppwzIndex != '\0' )
	{
		if( **ppwzIndex == ' ' )
		{
			if( ppwzValidPrefixes != NULL )
			{
				if( !IsStringInSet( pwzStart, *ppwzIndex - pwzStart, ppwzValidPrefixes ) )
				{
					**ppwzIndex = '\0';
					fInField = false;
				}
			}
			else
			{
				**ppwzIndex = '\0';
				fInField = false;
			}
		}
		else
		{
			if( !fInField )
			{
				return;
			}
		}

		*ppwzIndex += 1;
	}
}

///
/// Find the next operand, and the delimiter that triggered it. This function returns false if the string is empty, otherwise, it returns true.
///
bool
FindNextOperand( __in PCWSTR pwzOperand, __in PCWSTR pwzDelimiters, __out PCWSTR *ppwzNextOperand, __out size_t * pcchOperand, __out WCHAR * pchDelimiter )
{
	if( *pwzOperand == '\0' )
	{
		*ppwzNextOperand = pwzOperand;
		*pcchOperand = 0;
		*pchDelimiter = *pwzOperand;
		return( false );
	}

	*pcchOperand = wcscspn( pwzOperand, pwzDelimiters );
	*pchDelimiter = *(pwzOperand + *pcchOperand);

	if( *pchDelimiter != '\0' )
	{
		*ppwzNextOperand = pwzOperand + *pcchOperand + 1;
	}
	else
	{
		*ppwzNextOperand = pwzOperand + *pcchOperand;
	}

	return( true );
}

///
/// Find the operands for the instruction for x86 and x64
///
void
Findx86_x64Operands( INSTRUCTION *pInstruction, const INSTRUCTION_INFO& objInstructionInfo, PCWSTR *ppwzRegisters )
{
	// Set the implicit operands
	const OPERAND *pOperands = (const OPERAND *) objInstructionInfo.arrImplicitSourceRegisters;

	while( (pOperands != NULL) && pOperands->pwzOperand != NULL )
	{
		pInstruction->setSourceRegisters.insert( *pOperands );
		pOperands++;
	}

	pOperands = (const OPERAND *) objInstructionInfo.arrImplicitDestinationRegisters;

	while( (pOperands != NULL) && pOperands->pwzOperand != NULL )
	{
		pInstruction->setDestinationRegisters.insert( *pOperands );
		pOperands++;
	}

	pOperands = (const OPERAND *) objInstructionInfo.arrImplicitDestinationPointerRegisters;

	while( (pOperands != NULL) && pOperands->pwzOperand != NULL )
	{
		pInstruction->setDestinationPointerRegisters.insert( *pOperands );
		pOperands++;
	}

	pOperands = (const OPERAND *) &objInstructionInfo.arrImplicitPassedOrReturnedRegisters;

	while( (pOperands != NULL) && pOperands->pwzOperand != NULL )
	{
		pInstruction->setPassedOrReturnedRegisters.insert( *pOperands );
		pOperands++;
	}

	if( objInstructionInfo.eOperandClassification == NO_OPERANDS )
	{
		return;
	}

	// Set our search rules. Note that we have some special case code to handle EBP and ESP references, because we 
	// want to be able to track those. To do that, we end up with special monitoring flags and an extra backwards looking
	// operand pointer.
	bool fInSource = !HAS_DEST_OPERANDS( objInstructionInfo.eOperandClassification );
	bool fInIndirectReference = false;
	bool fInMonitoredPointerReference = false;
	PCWSTR pwzMonitoredPointerOperand = NULL;

	PCWSTR pwzOperand = pInstruction->pwzArguments;
	PCWSTR pwzNextOperand = NULL;
	size_t cchOperand;
	WCHAR chDelimiter;

	while( FindNextOperand( pwzOperand, L"[], :+-*", &pwzNextOperand, &cchOperand, &chDelimiter ) )
	{
		// Prepare for the next iteration
		PCWSTR pwzCurrentOperand = pwzOperand;
		pwzOperand = pwzNextOperand;

		// Cache state information for this iteration
		bool fWasInIndirectReference = fInIndirectReference;
		bool fWasInSource = fInSource;

		// Check the delimiter we found, because it can change things
		switch( chDelimiter )
		{
			case ',':
				fInSource = true;
				break;

			case '[':
				fInIndirectReference = true;
				break;

			case ']':
				fInIndirectReference = false;

				if( fInMonitoredPointerReference )
				{
					OPERAND objOperand;
					
					objOperand.pwzOperand = pwzMonitoredPointerOperand;
					objOperand.cchOperand = (pwzCurrentOperand - pwzMonitoredPointerOperand) + cchOperand;
					
					if( fWasInSource )
					{
						pInstruction->setSourceRegisters.insert( objOperand );
					}
					else
					{
						// If the destination operand is flagged as being unaffected by the instruction, don't add it
						// to the destination register set
						if( !HAS_DEST_OPERAND_AS_UNAFFECTED( objInstructionInfo.eOperandClassification ) )
						{
							pInstruction->setDestinationRegisters.insert( objOperand );
						}

						// If the destination is flagged as being an implied source register, we add it to the 
						// implied source registers as well
						if( HAS_DEST_OPERAND_AS_IMPLIED_SOURCE( objInstructionInfo.eOperandClassification ) )
						{
							pInstruction->setSourceRegisters.insert( objOperand );
						}
					}

					// We additionally tag registers that were explicitly defined, rather than implicitly defined
					pInstruction->setExplicitRegisters.insert( objOperand );

					fInMonitoredPointerReference = false;
					pwzMonitoredPointerOperand = NULL;

					// And we're done, since we've added the pointer reference as a logical register
					continue;
				}
				break;

			case ':':
				continue;
		}

		// Continue if we don't have any actual operand
		if( cchOperand == 0 )
		{
			continue;
		}

		// Otherwise, we have to check the operand found to see if we are going to add it to the list
		if( IsStringInSet( pwzCurrentOperand, cchOperand, X64_X86_EXCLUDED_OPERANDS ) )
		{
			fInMonitoredPointerReference = false;
			pwzMonitoredPointerOperand = NULL;
			continue;
		}

		/// Skip the numbers
		if( iswdigit( *pwzCurrentOperand ) )
		{
			continue;
		}

		// Skip items in parentheses 
		if( *pwzCurrentOperand == '(' )
		{
			fInMonitoredPointerReference = false;
			pwzMonitoredPointerOperand = NULL;
			continue;
		}

		// Skip anything that isn't a register
		if( !IsStringInSet( pwzCurrentOperand, cchOperand, ppwzRegisters ) )
		{
			continue;
		}

		// Check to see if this is a monitored register (for local variable references)
		if( fInIndirectReference &&
			(pwzCurrentOperand[cchOperand-1] == 'p') && (pwzMonitoredPointerOperand == NULL) &&
			((chDelimiter == '+') || (chDelimiter == '-')) )
		{
			fInMonitoredPointerReference = true;
			pwzMonitoredPointerOperand = pwzCurrentOperand;
		}
		else
		{
			fInMonitoredPointerReference = false;
			pwzMonitoredPointerOperand = NULL;
		}

		// Add the register
		OPERAND objOperand;
		
		objOperand.pwzOperand = pwzCurrentOperand;
		objOperand.cchOperand = cchOperand;

		if( fWasInSource )
		{
			pInstruction->setSourceRegisters.insert( objOperand );
		}
		else
		{
			// If the destination operand is flagged as being unaffected by the instruction, don't add it
			// to the destination register set
			if( !HAS_DEST_OPERAND_AS_UNAFFECTED( objInstructionInfo.eOperandClassification ) )
			{
				if( fWasInIndirectReference || !HAS_DEST_REGISTERS( objInstructionInfo.eOperandClassification) )
				{
					pInstruction->setDestinationPointerRegisters.insert( objOperand );
				}
				else
				{
					pInstruction->setDestinationRegisters.insert( objOperand );
				}
			}

			// If the destination is flagged as being an implied source register, we add it to the 
			// implied source registers as well
			if( HAS_DEST_OPERAND_AS_IMPLIED_SOURCE( objInstructionInfo.eOperandClassification ) )
			{
				pInstruction->setSourceRegisters.insert( objOperand );
			}
		}

		// We additionally tag registers that were explicitly defined, rather than implicitly defined
		pInstruction->setExplicitRegisters.insert( objOperand );
	}
}

///
/// Classify an X86 instruction as part of disassembly
///
bool
ClassifyX86Instruction( INSTRUCTION *pInstruction )
{
	DWORD cMnemonics = sizeof( X86_DISASSEMBLY_INFO ) / sizeof( INSTRUCTION_INFO );
	
	for( DWORD iMnemonic = 0; iMnemonic < cMnemonics; iMnemonic++ )
	{
		if( wcsncmp( X86_DISASSEMBLY_INFO[iMnemonic].pwzMnemonic, pInstruction->pwzMnemonic, X86_DISASSEMBLY_INFO[iMnemonic].cchMnemonic ) == 0 )
		{
			if( !X86_DISASSEMBLY_INFO[iMnemonic].fExactMatch ||
				(wcscmp( X86_DISASSEMBLY_INFO[iMnemonic].pwzMnemonic, pInstruction->pwzMnemonic ) == 0) )
			{
				pInstruction->eClass = X86_DISASSEMBLY_INFO[iMnemonic].eClassification;
				pInstruction->pInstructionInfo = &X86_DISASSEMBLY_INFO[iMnemonic];

				Findx86_x64Operands( pInstruction, X86_DISASSEMBLY_INFO[iMnemonic], X86_REGISTERS );

				// Allow for special case post-processing; this was originally added to handle the common practice
				// of using reflexive XOR operations in x86 or x64 assembly to clear registers
				if( X86_DISASSEMBLY_INFO[iMnemonic].pfuncAnalysisOverride != NULL )
				{
					X86_DISASSEMBLY_INFO[iMnemonic].pfuncAnalysisOverride( pInstruction, X86_DISASSEMBLY_INFO[iMnemonic] );
				}

				return( true );
			}
		}
	}

	return( true );
}

///
/// Classify an X64 instruction as part of disassembly
///
bool
ClassifyX64Instruction( INSTRUCTION * pInstruction )
{
	DWORD cMnemonics = sizeof( X64_DISASSEMBLY_INFO ) / sizeof( INSTRUCTION_INFO );
	
	for( DWORD iMnemonic = 0; iMnemonic < cMnemonics; iMnemonic++ )
	{
		if( wcsncmp( X64_DISASSEMBLY_INFO[iMnemonic].pwzMnemonic, pInstruction->pwzMnemonic, X64_DISASSEMBLY_INFO[iMnemonic].cchMnemonic ) == 0 )
		{
			if( !X64_DISASSEMBLY_INFO[iMnemonic].fExactMatch ||
				(wcscmp( X64_DISASSEMBLY_INFO[iMnemonic].pwzMnemonic, pInstruction->pwzMnemonic ) == 0) )
			{
				pInstruction->eClass = X64_DISASSEMBLY_INFO[iMnemonic].eClassification;
				pInstruction->pInstructionInfo = &X64_DISASSEMBLY_INFO[iMnemonic];

				Findx86_x64Operands( pInstruction, X64_DISASSEMBLY_INFO[iMnemonic], X64_REGISTERS );

				// Allow for special case post-processing; this was originally added to handle the common practice
				// of using reflexive XOR operations in x86 or x64 assembly to clear registers
				if( X64_DISASSEMBLY_INFO[iMnemonic].pfuncAnalysisOverride != NULL )
				{
					X64_DISASSEMBLY_INFO[iMnemonic].pfuncAnalysisOverride( pInstruction, X64_DISASSEMBLY_INFO[iMnemonic] );
				}

				return( true );
			}
		}
	}

	// Go with the default for the moment
	return( true );
}


///
// Analysis Override Functions
///

///
// Overide Function
// Remove the explicit source register references if they are also the explicit destination reference. This analysis override is primarily
// used for reflexive XOR operations
//
// This should only be used in cases (like the x86/x64 XOR EAX,EAX common pattern) where the result is independent of the
// source registers values
void
ReflexiveCancellationAnalysisOverride( INSTRUCTION *pInstruction, const INSTRUCTION_INFO&  )
{
	bool fIsReflexive = true;

	for( OPERAND_SET::const_iterator itOperand = pInstruction->setDestinationRegisters.begin(); fIsReflexive && (itOperand != pInstruction->setDestinationRegisters.end()); itOperand++ )
	{
		if( pInstruction->setExplicitRegisters.find( *itOperand ) != pInstruction->setExplicitRegisters.end() )
		{
			if( pInstruction->setSourceRegisters.find( *itOperand ) == pInstruction->setSourceRegisters.end() )
			{
				fIsReflexive = false;
			}
		}
	}

	for( OPERAND_SET::const_iterator itOperand = pInstruction->setSourceRegisters.begin(); fIsReflexive && (itOperand != pInstruction->setSourceRegisters.end()); itOperand++ )
	{
		if( pInstruction->setExplicitRegisters.find( *itOperand ) != pInstruction->setExplicitRegisters.end() )
		{
			if( pInstruction->setDestinationRegisters.find( *itOperand ) == pInstruction->setDestinationRegisters.end() )
			{
				fIsReflexive = false;
			}
		}
	}

	// If all of the source registers are also destination registers, then we clear the source registers because
	// effectively we only have a destination register
	if( fIsReflexive )
	{
		pInstruction->setSourceRegisters.clear();
	}
}


