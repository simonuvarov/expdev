RSP Software Inc. 2008 - I miss Corka and Ok12

RSP MP3 Player OCX 3.2.0

ActiveX OCX to play mp3 files

What is new in version 3.2.0(02/06/2008)
Fixed SoundTouch small bug , minor modifications

What is new in version 3.1.0(01/06/2008)
Added SoundTouch wave effect , minor modifications

What is new in version 2.8.0(07/05/2008)
Full Vista compliant , added freeverb wave
effect , minor bugs fixed

Installation and Usage:
Requires rspmp3ocx280s1.dll and rspmp3ocx280s2.dll
in the same path of the ocx or it will not work

Execute register.bat to install the ocx in the system
, in Vista you need to be admin to install OCXs

Documentaton is available online on the homepage

Homepage:
http://rspsoftware.com.br/rspmp3play.htm

Email:
rspsoftware@hotmail.com

Thanks for using our software